# Copyright 2022 Jiri Skoda <developer@skodaj.cz>
# 
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# 
#     http://www.apache.org/licenses/LICENSE-2.0
# 
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

'''
Script which minifies all code
'''
from datetime import datetime
import os
import sys
import shutil
import time
from css_html_js_minify import process_single_html_file, process_single_css_file, process_single_js_file


# Output directory of minifiing
OUTPUT = "./build"

# List of forbidden paths
FORBIDDEN = ["Dockerfile", "build.py"]


def get_all_files(path: str = "./") -> list:
    '''
    Function which lists all available files
    :param path: Path, which will be searched
    :returns: List with all available files 
    '''
    reti = []
    for item in os.listdir(path):
        item_path = path + item if path == "./" else path + "/" + item
        if os.path.isdir(item_path) and not item_path in FORBIDDEN:
            reti.extend(get_all_files(item_path))
        elif not item_path in FORBIDDEN:
            reti.append(item_path)
    return reti

def make_directory(dir: str) -> None:
    '''
    Function which creates directory if not exists
    :param dir: Directory which will be created
    '''
    if not os.path.exists(os.path.dirname(dir)):
        make_directory(os.path.dirname(dir))
    os.mkdir(dir)

def set_changedate(files: list):
    '''
    Sets last change date to each site
    '''
    newlines = []
    for file in files:
        f_name, f_ext = os.path.splitext(file)
        if f_ext == ".html":
            with open(file, "r", encoding="utf-8") as reader:
                for line in reader.readlines():
                    if "<span id=\"last-change-val\"></span>" in line:
                        now = datetime.now()
                        line = line.replace( "<span id=\"last-change-val\"></span>", "<span id=\"last-change-val\">" + now.strftime("%d.%m.%Y %H:%M:%S") + "</span>")
                        newlines.append(line)
                    else:
                        newlines.append(line)
            with open(file, "w", encoding="utf-8") as writer:
                for line in newlines:
                    writer.write(line)


def get_minifiable_files(files: list) -> list:
    '''
    Gets files which could be minified
    :param files: List which will be searched for minifiable files
    :returns: List with files which can be minified
    '''
    reti = []
    exts = [".html", ".js", ".css", ".phtml"]
    for file in files:
        f_name, f_ext = os.path.splitext(file)
        if f_ext in exts:
            reti.append(file)
    return reti

def minify_file(file: str) -> None:
    '''
    Minifies file
    :param file: File which will be minified
    '''
    sys.stdout = open(os.devnull, 'w')
    f_name, f_ext = os.path.splitext(file)
    if f_ext == ".html" or f_ext == ".phtml":
        process_single_html_file(file, overwrite=True)
    elif f_ext == ".css":
        process_single_css_file(file, overwrite=True)
    elif f_ext == ".js":
        process_single_js_file(file, overwrite=True)
    sys.stdout = sys.__stdout__

def main() -> None:
    '''
    Main function of program
    '''
    print("BUILD started (output: '" + OUTPUT + "')")    
    print("-------------------------------------------")
    start = time.time()
    if os.path.exists(OUTPUT):
        print("Deleting directory '" + OUTPUT + "'...", end="", flush=True)
        shutil.rmtree(OUTPUT)
        print("\t\t ✅", flush=True)
    print("Making output directory '" + OUTPUT + "'...", end="", flush=True)
    os.mkdir(OUTPUT)
    print("\t ✅", flush=True)
    print("Looking for files...", end="", flush=True)
    files = get_all_files()
    print("\t\t\t ✅", flush=True)
    print("Copying files(0/" + str(len(files)) + ")...", end="", flush=True)
    counter = 0
    outputs = []
    for file in files:
        strlen = len(str(counter)) + 1 + len(str(len(files))) + 4
        for i in range(0, strlen):
            print(chr(8), end="")
        counter += 1
        print(str(counter) + "/" + str(len(files)) + ")...", end="", flush=True)
        new_path = OUTPUT + "/" + file[2:]
        outputs.append(new_path)
        directory = os.path.dirname(new_path)
        if not os.path.exists(directory):
            make_directory(directory)
        shutil.copyfile(file, OUTPUT + "/" + file[2:])
    print("\t\t ✅", flush=True)
    print("Changing dates in files...", end = "", flush=True)
    set_changedate(outputs)
    print("\t\t ✅", flush=True)
    print("Looking for minifiable files...", end="", flush=True)
    min_f = get_minifiable_files(outputs)
    print("\t\t ✅", flush=True)
    counter = 0
    print("Minifying files(0/" + str(len(min_f)) + ")...", end="", flush=True)
    for file in min_f:
        strlen = len(str(counter)) + 1 + len(str(len(min_f))) + 4
        for i in range(0, strlen):
            print(chr(8), end="")
        counter += 1
        print(str(counter) + "/" + str(len(min_f)) + ")...", end="", flush=True)
        minify_file(file)
    print("\t\t ✅", flush=True)
    end = time.time()
    print("===========================================")
    print("FINISHED in " + str(round(end - start, 2)) + " s")
        

if __name__ == "__main__":
    main()


